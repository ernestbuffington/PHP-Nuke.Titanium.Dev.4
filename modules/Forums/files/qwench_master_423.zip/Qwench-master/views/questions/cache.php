<base href="<?php echo $cachelink;?>">
<?php echo $cache;?>
<div style="position:absolute;background-color:#21a5ca;color:#ffffff;font-weight:bold;font-family:verdana,arial;padding:4px;top:0;right:0;font-size:10px;padding-left:10px;padding-right:10px;">Cached Version of <?php echo $cachelink;?></div>