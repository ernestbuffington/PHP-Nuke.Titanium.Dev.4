<h1>You have successfully logged out</h1>
<script>setTimeout("location.href = '<?php echo basePath();?>'",3000);</script>