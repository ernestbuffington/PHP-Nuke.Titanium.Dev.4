<div class="userbox"> 
<a href="<?php echo basePath();?>/users/view/<?php echo $user['id'];?>/<?php echo createSlug($user['name']);?>"><?php echo $user['name'];?> | <?php echo $user['points'];?></a> 
</div>